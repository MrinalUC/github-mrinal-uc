/*This is the Constant Class*/
package com.mypackage.MyLib;

public class MyConstants {

	public static final String URL = "https://api.tmsandbox.co.nz/v1/Categories/6327/Details.json?catalogue=false";
    public static final String getMethod = "GET";
    public static String seachedText = "Gallery";
}
